<?php
/**
 * Onyx Essentials Module for Onyx Command
 * 
 * Module ID: onyx-essentials
 * Module Name: Onyx Essentials
 * Description: Comprehensive security, optimization, and maintenance tools for WordPress
 * Version: 1.0.0
 * Author: Callum Creed
 * 
 * INSTALLATION INSTRUCTIONS:
 * 1. Create directory: C:\Users\castl\Documents\GitHub\OnyxCommand\OnyxCommand\modules\onyx-essentials
 * 2. Place this file there as: onyx-essentials.php
 * 3. Create subdirectories: templates, assets\css, assets\js
 * 4. Place corresponding template and asset files in those directories
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main Onyx Essentials Module Class
 */
class OC_Onyx_Essentials {
    
    private static $instance = null;
    private $options_key = 'oc_essentials_options';
    private $locked_ips_key = 'oc_locked_ips';
    private $locked_users_key = 'oc_locked_users';
    private $login_attempts_key = 'oc_login_attempts';
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Admin hooks
        add_action('admin_menu', array($this, 'add_menu_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        
        // Load enabled features
        $this->load_enabled_features();
        
        // AJAX handlers
        add_action('wp_ajax_oc_essentials_action', array($this, 'handle_ajax_actions'));
        add_action('wp_ajax_oc_download_database', array($this, 'download_database'));
        add_action('wp_ajax_oc_download_site', array($this, 'download_site'));
        add_action('wp_ajax_oc_download_files_only', array($this, 'download_files_only'));
        add_action('wp_ajax_oc_regenerate_thumbnails', array($this, 'regenerate_thumbnails'));
        add_action('wp_ajax_oc_delete_unattached', array($this, 'delete_unattached_media'));
        add_action('wp_ajax_oc_clear_cache', array($this, 'clear_site_cache'));
        add_action('wp_ajax_oc_scan_orphaned', array($this, 'scan_orphaned_content'));
        add_action('wp_ajax_oc_scan_meta', array($this, 'scan_missing_meta'));
        add_action('wp_ajax_oc_scan_alt_text', array($this, 'scan_missing_alt_text'));
        add_action('wp_ajax_oc_unlock_ip', array($this, 'unlock_ip'));
        add_action('wp_ajax_oc_unlock_user', array($this, 'unlock_user'));
        add_action('wp_ajax_oc_upload_ssl', array($this, 'upload_ssl_certificate'));
        
        // Post meta box for comments
        add_action('add_meta_boxes', array($this, 'add_comment_meta_box'));
        add_action('save_post', array($this, 'save_comment_meta'));
        
        // Post/page cache clearing
        add_action('post_updated', array($this, 'clear_post_cache'), 10, 3);
    }
    
    /**
     * Load enabled features based on settings
     */
    private function load_enabled_features() {
        $options = get_option($this->options_key, array());
        
        // Feature 2: Force 2FA
        if (!empty($options['force_2fa'])) {
            add_action('admin_init', array($this, 'check_2fa_status'));
        }
        
        // Feature 3: Disable file editing
        if (!empty($options['disable_file_editing'])) {
            add_action('init', array($this, 'disable_file_editing'));
        }
        
        // Feature 4: Disable XML-RPC
        if (!empty($options['disable_xmlrpc'])) {
            add_filter('xmlrpc_enabled', '__return_false');
            add_filter('wp_headers', array($this, 'remove_xmlrpc_headers'));
        }
        
        // Feature 5: Disable wp-config editing
        if (!empty($options['disable_wpconfig_edit'])) {
            add_action('init', array($this, 'disable_wpconfig_editing'));
        }
        
        // Feature 6: Hide WordPress version
        if (!empty($options['hide_wp_version'])) {
            remove_action('wp_head', 'wp_generator');
            add_filter('the_generator', '__return_empty_string');
            add_filter('style_loader_src', array($this, 'remove_version_strings'), 9999);
            add_filter('script_loader_src', array($this, 'remove_version_strings'), 9999);
        }
        
        // Feature 7: Keep admins logged in
        if (!empty($options['keep_admin_logged_in'])) {
            add_filter('auth_cookie_expiration', array($this, 'extend_admin_login'), 10, 3);
        }
        
        // Feature 9: Disable comments sitewide
        if (!empty($options['disable_comments'])) {
            add_action('admin_init', array($this, 'disable_comments_admin'));
            add_filter('comments_open', array($this, 'filter_comments_status'), 20, 2);
            add_filter('pings_open', '__return_false');
            add_action('admin_menu', array($this, 'remove_comment_menu'));
            add_action('init', array($this, 'remove_comment_support'));
        }
        
        // Feature 12: Enforce strong passwords
        if (!empty($options['enforce_strong_passwords'])) {
            add_action('user_profile_update_errors', array($this, 'validate_strong_password'), 10, 3);
            add_action('validate_password_reset', array($this, 'validate_strong_password_reset'), 10, 2);
            add_action('registration_errors', array($this, 'validate_registration_password'), 10, 3);
        }
        
        // Feature 13 & 14: Login attempt limiting and blocking
        if (!empty($options['limit_login_attempts']) || !empty($options['block_invalid_usernames'])) {
            add_action('wp_login_failed', array($this, 'handle_login_failure'));
            add_filter('authenticate', array($this, 'check_login_attempts'), 30, 3);
        }
        
        // Feature 24: Disable emojis
        if (!empty($options['disable_emojis'])) {
            add_action('init', array($this, 'disable_emojis'));
        }
    }
    
    /**
     * Add admin menu page
     */
    public function add_menu_page() {
        add_submenu_page(
            'onyx-command',
            'Onyx Essentials',
            'Onyx Essentials',
            'manage_options',
            'onyx-essentials',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('oc_essentials_group', $this->options_key);
    }
    
    /**
     * Enqueue assets
     */
    public function enqueue_assets($hook) {
        if (strpos($hook, 'onyx-essentials') === false) {
            return;
        }
        
        $module_url = plugin_dir_url(__FILE__);
        
        wp_enqueue_style('oc-essentials-style', $module_url . 'assets/css/essentials.css', array(), '1.0.0');
        wp_enqueue_script('oc-essentials-script', $module_url . 'assets/js/essentials.js', array('jquery'), '1.0.0', true);
        
        wp_localize_script('oc-essentials-script', 'ocEssentials', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('oc_essentials_nonce'),
            'site_url' => home_url()
        ));
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Save settings
        if (isset($_POST['oc_essentials_save']) && check_admin_referer('oc_essentials_settings')) {
            $options = array();
            
            // Save each option
            $features = array(
                'ssl_check', 'force_2fa', 'disable_file_editing', 'disable_xmlrpc',
                'disable_wpconfig_edit', 'hide_wp_version', 'keep_admin_logged_in',
                'change_admin_username', 'disable_comments', 'enforce_strong_passwords',
                'limit_login_attempts', 'block_invalid_usernames', 'disable_emojis'
            );
            
            foreach ($features as $feature) {
                $options[$feature] = isset($_POST[$feature]) ? 1 : 0;
            }
            
            // Save login attempt limit
            if (isset($_POST['login_attempt_limit'])) {
                $options['login_attempt_limit'] = intval($_POST['login_attempt_limit']);
            }
            
            // Handle admin username change
            if (!empty($_POST['new_admin_username']) && !empty($options['change_admin_username'])) {
                $result = $this->change_admin_username(sanitize_user($_POST['new_admin_username']));
                if ($result) {
                    echo '<div class="notice notice-success"><p>Admin username changed successfully!</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>Failed to change admin username. Username may already exist.</p></div>';
                }
            }
            
            update_option($this->options_key, $options);
            echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
        }
        
        $options = get_option($this->options_key, array());
        $ssl_info = $this->get_ssl_info();
        $locked_ips = get_option($this->locked_ips_key, array());
        $locked_users = get_option($this->locked_users_key, array());
        
        include(dirname(__FILE__) . '/templates/settings.php');
    }
    
    /**
     * Feature 1: Get SSL Information
     */
    private function get_ssl_info() {
        $info = array(
            'is_ssl' => is_ssl(),
            'status' => 'Unknown',
            'expiry_date' => null,
            'days_remaining' => null,
            'issuer' => null
        );
        
        if (!is_ssl()) {
            $info['status'] = 'Not Active';
            return $info;
        }
        
        $domain = parse_url(home_url(), PHP_URL_HOST);
        
        $context = stream_context_create(array(
            'ssl' => array(
                'capture_peer_cert' => true,
                'verify_peer' => false,
                'verify_peer_name' => false
            )
        ));
        
        $stream = @stream_socket_client(
            'ssl://' . $domain . ':443',
            $errno,
            $errstr,
            30,
            STREAM_CLIENT_CONNECT,
            $context
        );
        
        if ($stream) {
            $params = stream_context_get_params($stream);
            $cert = openssl_x509_parse($params['options']['ssl']['peer_certificate']);
            
            if ($cert) {
                $expiry_timestamp = $cert['validTo_time_t'];
                $info['expiry_date'] = date('Y-m-d H:i:s', $expiry_timestamp);
                $info['days_remaining'] = floor(($expiry_timestamp - time()) / 86400);
                $info['issuer'] = isset($cert['issuer']['O']) ? $cert['issuer']['O'] : 'Unknown';
                
                if ($info['days_remaining'] > 0) {
                    $info['status'] = 'Active';
                } else {
                    $info['status'] = 'Expired';
                }
            }
            
            fclose($stream);
        }
        
        return $info;
    }
    
    /**
     * Feature 1: Upload SSL Certificate
     */
    public function upload_ssl_certificate() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        if (!isset($_FILES['ssl_cert']) || !isset($_FILES['ssl_key'])) {
            wp_send_json_error('Certificate and key files are required');
        }
        
        // This is a placeholder - actual SSL installation requires server-level access
        // In a shared hosting environment, this would need to use hosting provider APIs
        wp_send_json_success(array(
            'message' => 'SSL certificate upload requires server-level access. Please install manually via your hosting control panel or contact your hosting provider.'
        ));
    }
    
    /**
     * Feature 2: Check 2FA Status
     */
    public function check_2fa_status() {
        $user = wp_get_current_user();
        
        if (!in_array('administrator', $user->roles) && !in_array('contributor', $user->roles)) {
            return;
        }
        
        $has_2fa = get_user_meta($user->ID, 'oc_2fa_enabled', true);
        
        if (!$has_2fa && (!isset($_GET['page']) || $_GET['page'] !== 'oc-setup-2fa')) {
            // Redirect to 2FA setup page
            // Note: This requires a separate 2FA setup page to be created
            wp_die('Please set up Two-Factor Authentication before accessing the admin dashboard. <a href="' . admin_url('profile.php') . '">Set up 2FA</a>');
        }
    }
    
    /**
     * Feature 3: Disable file editing
     */
    public function disable_file_editing() {
        if (!current_user_can('administrator') && !is_super_admin()) {
            if (!defined('DISALLOW_FILE_EDIT')) {
                define('DISALLOW_FILE_EDIT', true);
            }
        }
    }
    
    /**
     * Feature 4: Remove XML-RPC headers
     */
    public function remove_xmlrpc_headers($headers) {
        unset($headers['X-Pingback']);
        return $headers;
    }
    
    /**
     * Feature 5: Disable wp-config editing
     */
    public function disable_wpconfig_editing() {
        if (!current_user_can('administrator') && !is_super_admin()) {
            if (!defined('DISALLOW_FILE_MODS')) {
                define('DISALLOW_FILE_MODS', true);
            }
        }
    }
    
    /**
     * Feature 6: Remove version strings
     */
    public function remove_version_strings($src) {
        if (strpos($src, 'ver=')) {
            $src = remove_query_arg('ver', $src);
        }
        return $src;
    }
    
    /**
     * Feature 7: Extend admin login
     */
    public function extend_admin_login($expiration, $user_id, $remember) {
        $user = get_userdata($user_id);
        
        if ($user && in_array('administrator', $user->roles)) {
            return YEAR_IN_SECONDS * 10; // 10 years
        }
        
        return $expiration;
    }
    
    /**
     * Feature 8 & 11: Change admin username
     */
    private function change_admin_username($new_username) {
        global $wpdb;
        
        if (username_exists($new_username)) {
            return false;
        }
        
        $admin_user = get_user_by('login', 'admin');
        
        if (!$admin_user) {
            // Try to find first administrator
            $admins = get_users(array('role' => 'administrator', 'number' => 1));
            if (empty($admins)) {
                return false;
            }
            $admin_user = $admins[0];
        }
        
        $wpdb->update(
            $wpdb->users,
            array('user_login' => $new_username, 'user_nicename' => $new_username),
            array('ID' => $admin_user->ID),
            array('%s', '%s'),
            array('%d')
        );
        
        clean_user_cache($admin_user->ID);
        
        return true;
    }
    
    /**
     * Feature 9: Comment controls
     */
    public function disable_comments_admin() {
        global $pagenow;
        
        if ($pagenow === 'edit-comments.php' || $pagenow === 'options-discussion.php') {
            wp_redirect(admin_url());
            exit;
        }
    }
    
    public function filter_comments_status($open, $post_id) {
        $allow_comments = get_post_meta($post_id, '_oc_allow_comments', true);
        return $allow_comments ? true : false;
    }
    
    public function remove_comment_menu() {
        remove_menu_page('edit-comments.php');
    }
    
    public function remove_comment_support() {
        $post_types = get_post_types();
        foreach ($post_types as $post_type) {
            if (post_type_supports($post_type, 'comments')) {
                remove_post_type_support($post_type, 'comments');
                remove_post_type_support($post_type, 'trackbacks');
            }
        }
    }
    
    public function add_comment_meta_box() {
        $options = get_option($this->options_key, array());
        
        if (empty($options['disable_comments'])) {
            return;
        }
        
        add_meta_box(
            'oc_comment_control',
            'Comment Control',
            array($this, 'render_comment_meta_box'),
            array('post', 'page'),
            'side',
            'high'
        );
    }
    
    public function render_comment_meta_box($post) {
        wp_nonce_field('oc_comment_meta', 'oc_comment_nonce');
        $allow = get_post_meta($post->ID, '_oc_allow_comments', true);
        ?>
        <label>
            <input type="checkbox" name="oc_allow_comments" value="1" <?php checked($allow, '1'); ?>>
            Allow comments on this <?php echo $post->post_type; ?>
        </label>
        <?php
    }
    
    public function save_comment_meta($post_id) {
        if (!isset($_POST['oc_comment_nonce']) || !wp_verify_nonce($_POST['oc_comment_nonce'], 'oc_comment_meta')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        $allow = isset($_POST['oc_allow_comments']) ? '1' : '0';
        update_post_meta($post_id, '_oc_allow_comments', $allow);
        
        // Update comment status
        if ($allow) {
            wp_update_post(array(
                'ID' => $post_id,
                'comment_status' => 'open'
            ));
        } else {
            wp_update_post(array(
                'ID' => $post_id,
                'comment_status' => 'closed'
            ));
        }
    }
    
    /**
     * Feature 12: Validate strong passwords
     */
    public function validate_strong_password($errors, $update, $user) {
        if (empty($_POST['pass1']) || empty($_POST['pass2'])) {
            return;
        }
        
        $password = $_POST['pass1'];
        
        if (!$this->is_strong_password($password)) {
            $errors->add('weak_password', '<strong>ERROR</strong>: Password must be at least 8 characters long and contain uppercase letter, lowercase letter, number, and special character.');
        }
    }
    
    public function validate_strong_password_reset($errors, $user) {
        if (!empty($_POST['pass1']) && !$this->is_strong_password($_POST['pass1'])) {
            $errors->add('weak_password', '<strong>ERROR</strong>: Password must be at least 8 characters long and contain uppercase letter, lowercase letter, number, and special character.');
        }
    }
    
    public function validate_registration_password($errors, $sanitized_user_login, $user_email) {
        if (!empty($_POST['password']) && !$this->is_strong_password($_POST['password'])) {
            $errors->add('weak_password', '<strong>ERROR</strong>: Password must be at least 8 characters long and contain uppercase letter, lowercase letter, number, and special character.');
        }
        return $errors;
    }
    
    private function is_strong_password($password) {
        if (strlen($password) < 8) {
            return false;
        }
        
        if (!preg_match('/[a-z]/', $password)) {
            return false;
        }
        
        if (!preg_match('/[A-Z]/', $password)) {
            return false;
        }
        
        if (!preg_match('/[0-9]/', $password)) {
            return false;
        }
        
        if (!preg_match('/[^a-zA-Z0-9]/', $password)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Feature 13 & 14: Login attempt limiting
     */
    public function handle_login_failure($username) {
        $options = get_option($this->options_key, array());
        $attempts = get_option($this->login_attempts_key, array());
        $user_ip = $this->get_user_ip();
        
        // Check if username exists
        if (!empty($options['block_invalid_usernames']) && !username_exists($username) && !is_email($username)) {
            $locked_ips = get_option($this->locked_ips_key, array());
            $locked_ips[$user_ip] = array(
                'username' => $username,
                'country' => $this->get_country_from_ip($user_ip),
                'locked_at' => current_time('mysql'),
                'attempts' => isset($locked_ips[$user_ip]) ? $locked_ips[$user_ip]['attempts'] + 1 : 1
            );
            update_option($this->locked_ips_key, $locked_ips);
            return;
        }
        
        // Track login attempts
        if (!empty($options['limit_login_attempts'])) {
            $limit = isset($options['login_attempt_limit']) ? $options['login_attempt_limit'] : 5;
            $key = $username . '|' . $user_ip;
            
            if (!isset($attempts[$key])) {
                $attempts[$key] = array('count' => 0, 'first_attempt' => time());
            }
            
            $attempts[$key]['count']++;
            $attempts[$key]['last_attempt'] = time();
            
            if ($attempts[$key]['count'] >= $limit) {
                $user = get_user_by('login', $username);
                if (!$user) {
                    $user = get_user_by('email', $username);
                }
                
                if ($user) {
                    $locked_users = get_option($this->locked_users_key, array());
                    $locked_users[$user->ID] = array(
                        'username' => $user->user_login,
                        'email' => $user->user_email,
                        'ip' => $user_ip,
                        'country' => $this->get_country_from_ip($user_ip),
                        'attempts' => $attempts[$key]['count'],
                        'locked_at' => current_time('mysql')
                    );
                    update_option($this->locked_users_key, $locked_users);
                }
            }
            
            update_option($this->login_attempts_key, $attempts);
        }
    }
    
    public function check_login_attempts($user, $username, $password) {
        if (empty($username) || empty($password)) {
            return $user;
        }
        
        $user_ip = $this->get_user_ip();
        
        // Check if IP is locked
        $locked_ips = get_option($this->locked_ips_key, array());
        if (isset($locked_ips[$user_ip])) {
            return new WP_Error('ip_locked', '<strong>ERROR</strong>: This IP address has been locked due to invalid login attempts. Please contact an administrator.');
        }
        
        // Check if user is locked
        $user_obj = get_user_by('login', $username);
        if (!$user_obj) {
            $user_obj = get_user_by('email', $username);
        }
        
        if ($user_obj) {
            $locked_users = get_option($this->locked_users_key, array());
            if (isset($locked_users[$user_obj->ID])) {
                return new WP_Error('account_locked', '<strong>ERROR</strong>: This account has been locked due to too many failed login attempts. Please contact an administrator.');
            }
        }
        
        return $user;
    }
    
    /**
     * Feature 20: Clear post/page cache
     */
    public function clear_post_cache($post_id, $post_after, $post_before) {
        // Clear object cache for this post
        wp_cache_delete($post_id, 'posts');
        wp_cache_delete($post_id, 'post_meta');
        
        // Clear common caching plugins for this specific post
        if (function_exists('wp_cache_post_change')) {
            wp_cache_post_change($post_id);
        }
        
        if (function_exists('w3tc_flush_post')) {
            w3tc_flush_post($post_id);
        }
        
        if (function_exists('wp_rocket_clean_post')) {
            wp_rocket_clean_post($post_id);
        }
    }
    
    /**
     * Feature 24: Disable emojis
     */
    public function disable_emojis() {
        remove_action('wp_head', 'print_emoji_detection_script', 7);
        remove_action('admin_print_scripts', 'print_emoji_detection_script');
        remove_action('wp_print_styles', 'print_emoji_styles');
        remove_action('admin_print_styles', 'print_emoji_styles');
        remove_filter('the_content_feed', 'wp_staticize_emoji');
        remove_filter('comment_text_rss', 'wp_staticize_emoji');
        remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
        
        add_filter('tiny_mce_plugins', function($plugins) {
            return is_array($plugins) ? array_diff($plugins, array('wpemoji')) : array();
        });
        
        add_filter('wp_resource_hints', function($urls, $relation_type) {
            if ('dns-prefetch' === $relation_type) {
                $emoji_svg_url = apply_filters('emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/');
                $urls = array_diff($urls, array($emoji_svg_url));
            }
            return $urls;
        }, 10, 2);
    }
    
    /**
     * AJAX: Download database
     */
    public function download_database() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        global $wpdb;
        
        // Start output buffering
        ob_start();
        
        $filename = 'database-backup-' . sanitize_file_name(get_bloginfo('name')) . '-' . date('Y-m-d-His') . '.sql';
        
        // Set headers for download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $tables = $wpdb->get_results('SHOW TABLES', ARRAY_N);
        
        echo "-- WordPress Database Backup\n";
        echo "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        echo "-- Site: " . get_bloginfo('name') . "\n";
        echo "-- URL: " . home_url() . "\n\n";
        
        foreach ($tables as $table) {
            $table_name = $table[0];
            
            // Get table structure
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table_name`", ARRAY_N);
            echo "\n\n-- Table structure for $table_name\n";
            echo "DROP TABLE IF EXISTS `$table_name`;\n";
            echo $create_table[1] . ";\n\n";
            
            // Get table data
            echo "-- Data for $table_name\n";
            $rows = $wpdb->get_results("SELECT * FROM `$table_name`", ARRAY_A);
            
            if ($rows) {
                foreach ($rows as $row) {
                    $values = array();
                    foreach ($row as $value) {
                        if (is_null($value)) {
                            $values[] = 'NULL';
                        } else {
                            $values[] = "'" . $wpdb->_real_escape($value) . "'";
                        }
                    }
                    echo "INSERT INTO `$table_name` VALUES(" . implode(', ', $values) . ");\n";
                }
            }
        }
        
        // Get the output and clean buffer
        $sql_content = ob_get_clean();
        
        // Send the content
        echo $sql_content;
        
        exit;
    }
    
    /**
     * AJAX: Download entire site
     */
    public function download_site() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        // Set time limit
        set_time_limit(0);
        ini_set('memory_limit', '512M');
        
        $filename = 'site-backup-' . sanitize_file_name(get_bloginfo('name')) . '-' . date('Y-m-d-His') . '.zip';
        $temp_dir = get_temp_dir();
        $zip_path = $temp_dir . $filename;
        
        // Create zip archive
        $zip = new ZipArchive();
        
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
            wp_send_json_error('Cannot create zip file');
        }
        
        // Add WordPress files
        $root_path = ABSPATH;
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root_path),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $file_path = $file->getRealPath();
                $relative_path = substr($file_path, strlen($root_path));
                $zip->addFile($file_path, $relative_path);
            }
        }
        
        // Add database backup
        global $wpdb;
        $db_backup = '';
        $tables = $wpdb->get_results('SHOW TABLES', ARRAY_N);
        
        foreach ($tables as $table) {
            $table_name = $table[0];
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table_name`", ARRAY_N);
            $db_backup .= "\n\n" . $create_table[1] . ";\n\n";
            
            $rows = $wpdb->get_results("SELECT * FROM `$table_name`", ARRAY_A);
            if ($rows) {
                foreach ($rows as $row) {
                    $values = array();
                    foreach ($row as $value) {
                        $values[] = is_null($value) ? 'NULL' : "'" . $wpdb->_real_escape($value) . "'";
                    }
                    $db_backup .= "INSERT INTO `$table_name` VALUES(" . implode(', ', $values) . ");\n";
                }
            }
        }
        
        $zip->addFromString('database-backup.sql', $db_backup);
        $zip->close();
        
        // Send file for download
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($zip_path));
        readfile($zip_path);
        
        // Clean up
        unlink($zip_path);
        
        exit;
    }
    
    /**
     * AJAX: Download files only (no media)
     */
    public function download_files_only() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        set_time_limit(0);
        ini_set('memory_limit', '512M');
        
        $filename = 'files-backup-' . sanitize_file_name(get_bloginfo('name')) . '-' . date('Y-m-d-His') . '.zip';
        $temp_dir = get_temp_dir();
        $zip_path = $temp_dir . $filename;
        
        $zip = new ZipArchive();
        
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
            wp_send_json_error('Cannot create zip file');
        }
        
        $root_path = ABSPATH;
        $upload_dir = wp_upload_dir();
        $uploads_path = $upload_dir['basedir'];
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root_path),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $file_path = $file->getRealPath();
                
                // Skip uploads directory
                if (strpos($file_path, $uploads_path) === 0) {
                    continue;
                }
                
                $relative_path = substr($file_path, strlen($root_path));
                $zip->addFile($file_path, $relative_path);
            }
        }
        
        $zip->close();
        
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($zip_path));
        readfile($zip_path);
        
        unlink($zip_path);
        
        exit;
    }
    
    /**
     * AJAX: Regenerate thumbnails
     */
    public function regenerate_thumbnails() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $attachments = get_posts(array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'numberposts' => -1
        ));
        
        $count = 0;
        $errors = 0;
        
        foreach ($attachments as $attachment) {
            $filepath = get_attached_file($attachment->ID);
            
            if ($filepath && file_exists($filepath)) {
                // Delete existing thumbnails
                $metadata = wp_get_attachment_metadata($attachment->ID);
                if (isset($metadata['sizes']) && is_array($metadata['sizes'])) {
                    foreach ($metadata['sizes'] as $size => $size_data) {
                        $thumb_path = path_join(dirname($filepath), $size_data['file']);
                        if (file_exists($thumb_path)) {
                            @unlink($thumb_path);
                        }
                    }
                }
                
                // Regenerate
                $metadata = wp_generate_attachment_metadata($attachment->ID, $filepath);
                if ($metadata) {
                    wp_update_attachment_metadata($attachment->ID, $metadata);
                    $count++;
                } else {
                    $errors++;
                }
            }
        }
        
        wp_send_json_success(array(
            'message' => "Regenerated thumbnails for {$count} images." . ($errors > 0 ? " {$errors} errors occurred." : ""),
            'count' => $count,
            'errors' => $errors
        ));
    }
    
    /**
     * AJAX: Delete unattached media
     */
    public function delete_unattached_media() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $attachments = get_posts(array(
            'post_type' => 'attachment',
            'post_status' => 'any',
            'numberposts' => -1,
            'post_parent' => 0
        ));
        
        $count = 0;
        foreach ($attachments as $attachment) {
            if (wp_delete_attachment($attachment->ID, true)) {
                $count++;
            }
        }
        
        wp_send_json_success(array(
            'message' => "Deleted {$count} unattached files and their thumbnails.",
            'count' => $count
        ));
    }
    
    /**
     * AJAX: Clear site cache
     */
    public function clear_site_cache() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        if ($post_id > 0) {
            // Clear specific post cache
            wp_cache_delete($post_id, 'posts');
            wp_cache_delete($post_id, 'post_meta');
            
            if (function_exists('wp_cache_post_change')) {
                wp_cache_post_change($post_id);
            }
            
            $message = 'Post cache cleared successfully.';
        } else {
            // Clear entire site cache
            wp_cache_flush();
            
            // Clear common caching plugins
            if (function_exists('wp_cache_clear_cache')) {
                wp_cache_clear_cache();
            }
            
            if (function_exists('w3tc_flush_all')) {
                w3tc_flush_all();
            }
            
            if (function_exists('wp_rocket_clean_domain')) {
                wp_rocket_clean_domain();
            }
            
            if (class_exists('WpFastestCache')) {
                $cache = new WpFastestCache();
                $cache->deleteCache();
            }
            
            if (function_exists('litespeed_purge_all')) {
                litespeed_purge_all();
            }
            
            $message = 'Entire site cache cleared successfully.';
        }
        
        wp_send_json_success(array('message' => $message));
    }
    
    /**
     * AJAX: Scan orphaned content
     */
    public function scan_orphaned_content() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        global $wpdb;
        
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'numberposts' => -1
        ));
        
        $orphaned = array();
        
        foreach ($posts as $post) {
            $permalink = get_permalink($post->ID);
            $post_url_slug = basename($permalink);
            
            // Check if linked from any other post
            $links = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} 
                WHERE (post_content LIKE %s OR post_content LIKE %s) 
                AND ID != %d 
                AND post_status = 'publish'",
                '%' . $wpdb->esc_like($permalink) . '%',
                '%' . $wpdb->esc_like($post_url_slug) . '%',
                $post->ID
            ));
            
            // Check if in menu
            $in_menu = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} 
                WHERE meta_key = '_menu_item_object_id' 
                AND meta_value = %d",
                $post->ID
            ));
            
            if ($links == 0 && $in_menu == 0) {
                // Find suggested posts
                $suggestions = array();
                
                // By category
                $categories = wp_get_post_categories($post->ID);
                if ($categories) {
                    $related = get_posts(array(
                        'category__in' => $categories,
                        'post__not_in' => array($post->ID),
                        'numberposts' => 3,
                        'post_status' => 'publish'
                    ));
                    
                    foreach ($related as $rel) {
                        $suggestions[] = array(
                            'title' => $rel->post_title,
                            'edit_url' => get_edit_post_link($rel->ID)
                        );
                    }
                }
                
                // By tags
                if (empty($suggestions)) {
                    $tags = wp_get_post_tags($post->ID, array('fields' => 'ids'));
                    if ($tags) {
                        $related = get_posts(array(
                            'tag__in' => $tags,
                            'post__not_in' => array($post->ID),
                            'numberposts' => 3,
                            'post_status' => 'publish'
                        ));
                        
                        foreach ($related as $rel) {
                            $suggestions[] = array(
                                'title' => $rel->post_title,
                                'edit_url' => get_edit_post_link($rel->ID)
                            );
                        }
                    }
                }
                
                $orphaned[] = array(
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'url' => $permalink,
                    'edit_url' => get_edit_post_link($post->ID),
                    'type' => $post->post_type,
                    'suggestions' => $suggestions
                );
            }
        }
        
        wp_send_json_success(array(
            'orphaned' => $orphaned,
            'count' => count($orphaned)
        ));
    }
    
    /**
     * AJAX: Scan missing meta
     */
    public function scan_missing_meta() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'numberposts' => -1
        ));
        
        $missing_meta = array();
        $seo_plugin = 'none';
        
        // Detect SEO plugin
        if (defined('WPSEO_VERSION')) {
            $seo_plugin = 'yoast';
        } elseif (class_exists('RankMath')) {
            $seo_plugin = 'rankmath';
        } elseif (defined('AIOSEO_VERSION')) {
            $seo_plugin = 'aioseo';
        }
        
        foreach ($posts as $post) {
            $missing = array();
            
            if ($seo_plugin === 'yoast') {
                $focus_keyword = get_post_meta($post->ID, '_yoast_wpseo_focuskw', true);
                $meta_title = get_post_meta($post->ID, '_yoast_wpseo_title', true);
                $meta_desc = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true);
                
                if (empty($focus_keyword)) $missing[] = 'Focus Keyphrase';
                if (empty($meta_title)) $missing[] = 'SEO Title';
                if (empty($meta_desc)) $missing[] = 'Meta Description';
                
            } elseif ($seo_plugin === 'rankmath') {
                $focus_keyword = get_post_meta($post->ID, 'rank_math_focus_keyword', true);
                $meta_title = get_post_meta($post->ID, 'rank_math_title', true);
                $meta_desc = get_post_meta($post->ID, 'rank_math_description', true);
                
                if (empty($focus_keyword)) $missing[] = 'Focus Keyword';
                if (empty($meta_title)) $missing[] = 'SEO Title';
                if (empty($meta_desc)) $missing[] = 'SEO Description';
                
            } elseif ($seo_plugin === 'aioseo') {
                $aioseo_data = get_post_meta($post->ID, '_aioseo_title', true);
                $meta_title = get_post_meta($post->ID, '_aioseo_title', true);
                $meta_desc = get_post_meta($post->ID, '_aioseo_description', true);
                
                if (empty($meta_title)) $missing[] = 'SEO Title';
                if (empty($meta_desc)) $missing[] = 'SEO Description';
            }
            
            if (!empty($missing)) {
                $missing_meta[] = array(
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'type' => $post->post_type,
                    'edit_url' => get_edit_post_link($post->ID),
                    'missing' => $missing
                );
            }
        }
        
        wp_send_json_success(array(
            'missing_meta' => $missing_meta,
            'count' => count($missing_meta),
            'seo_plugin' => $seo_plugin
        ));
    }
    
    /**
     * AJAX: Scan missing alt text
     */
    public function scan_missing_alt_text() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $attachments = get_posts(array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'numberposts' => -1,
            'post_status' => 'any'
        ));
        
        $missing = array();
        
        foreach ($attachments as $attachment) {
            $alt_text = get_post_meta($attachment->ID, '_wp_attachment_image_alt', true);
            
            if (empty($alt_text)) {
                $missing[] = array(
                    'id' => $attachment->ID,
                    'title' => $attachment->post_title,
                    'url' => wp_get_attachment_url($attachment->ID),
                    'thumb' => wp_get_attachment_image_url($attachment->ID, 'thumbnail'),
                    'edit_url' => get_edit_post_link($attachment->ID)
                );
            }
        }
        
        // Check if AI Alt Tag Manager is installed
        $has_ai_alt_tag = is_plugin_active('ai-alt-tag-manager/ai-alt-tag-manager.php');
        
        wp_send_json_success(array(
            'missing' => $missing,
            'count' => count($missing),
            'has_ai_alt_tag' => $has_ai_alt_tag,
            'ai_alt_tag_url' => admin_url('upload.php?page=missing-alt-tags')
        ));
    }
    
    /**
     * AJAX: Unlock IP
     */
    public function unlock_ip() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $ip = sanitize_text_field($_POST['ip']);
        
        $locked_ips = get_option($this->locked_ips_key, array());
        
        if (isset($locked_ips[$ip])) {
            unset($locked_ips[$ip]);
            update_option($this->locked_ips_key, $locked_ips);
            wp_send_json_success(array('message' => 'IP unlocked successfully.'));
        } else {
            wp_send_json_error('IP not found.');
        }
    }
    
    /**
     * AJAX: Unlock user
     */
    public function unlock_user() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $user_id = intval($_POST['user_id']);
        
        $locked_users = get_option($this->locked_users_key, array());
        
        if (isset($locked_users[$user_id])) {
            unset($locked_users[$user_id]);
            update_option($this->locked_users_key, $locked_users);
            
            // Also clear login attempts
            $attempts = get_option($this->login_attempts_key, array());
            foreach ($attempts as $key => $data) {
                if (strpos($key, '|') !== false) {
                    list($username, $ip) = explode('|', $key);
                    $user = get_user_by('login', $username);
                    if ($user && $user->ID == $user_id) {
                        unset($attempts[$key]);
                    }
                }
            }
            update_option($this->login_attempts_key, $attempts);
            
            wp_send_json_success(array('message' => 'User unlocked successfully.'));
        } else {
            wp_send_json_error('User not found.');
        }
    }
    
    /**
     * Helper: Get user IP
     */
    private function get_user_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        } else {
            return sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }
    }
    
    /**
     * Helper: Get country from IP
     */
    private function get_country_from_ip($ip) {
        // Use a free IP geolocation service
        $response = wp_remote_get("http://ip-api.com/json/{$ip}?fields=country", array('timeout' => 5));
        
        if (is_wp_error($response)) {
            return 'Unknown';
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        return isset($data['country']) ? $data['country'] : 'Unknown';
    }
    
    /**
     * General AJAX handler for various actions
     */
    public function handle_ajax_actions() {
        check_ajax_referer('oc_essentials_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $action = sanitize_text_field($_POST['sub_action']);
        
        switch ($action) {
            case 'check_ssl':
                $ssl_info = $this->get_ssl_info();
                wp_send_json_success($ssl_info);
                break;
                
            default:
                wp_send_json_error('Invalid action');
        }
    }
}

// Initialize the module
OC_Onyx_Essentials::get_instance();
