/**
 * Onyx Essentials JavaScript
 * Place in: modules/onyx-essentials/assets/js/essentials.js
 * 
 * This file is loaded via wp_localize_script with ocEssentials object containing:
 * - ajax_url: WordPress AJAX endpoint
 * - nonce: Security nonce
 * - site_url: Site home URL
 */

(function($) {
    'use strict';
    
    // Wait for DOM ready
    $(document).ready(function() {
        
        /**
         * Unlock User Account
         */
        $('.oc-unlock-user').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to unlock this user account?')) {
                return;
            }
            
            var userId = $(this).data('user-id');
            var $button = $(this);
            var $row = $button.closest('tr');
            
            $button.prop('disabled', true).text('Unlocking...');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_unlock_user',
                nonce: ocEssentials.nonce,
                user_id: userId
            })
            .done(function(response) {
                if (response.success) {
                    $row.fadeOut(300, function() {
                        $(this).remove();
                        // Check if table is empty
                        if ($('.oc-unlock-user').length === 0) {
                            $('.oc-locked-section').first().fadeOut();
                        }
                    });
                    showNotice('success', response.data.message);
                } else {
                    showNotice('error', 'Error: ' + (response.data || 'Unknown error'));
                    $button.prop('disabled', false).text('Unlock');
                }
            })
            .fail(function() {
                showNotice('error', 'Network error occurred');
                $button.prop('disabled', false).text('Unlock');
            });
        });
        
        /**
         * Unlock IP Address
         */
        $('.oc-unlock-ip').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to unlock this IP address?')) {
                return;
            }
            
            var ip = $(this).data('ip');
            var $button = $(this);
            var $row = $button.closest('tr');
            
            $button.prop('disabled', true).text('Unlocking...');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_unlock_ip',
                nonce: ocEssentials.nonce,
                ip: ip
            })
            .done(function(response) {
                if (response.success) {
                    $row.fadeOut(300, function() {
                        $(this).remove();
                        // Check if table is empty
                        if ($('.oc-unlock-ip').length === 0) {
                            $('.oc-locked-section').last().fadeOut();
                        }
                    });
                    showNotice('success', response.data.message);
                } else {
                    showNotice('error', 'Error: ' + (response.data || 'Unknown error'));
                    $button.prop('disabled', false).text('Unlock');
                }
            })
            .fail(function() {
                showNotice('error', 'Network error occurred');
                $button.prop('disabled', false).text('Unlock');
            });
        });
        
        /**
         * Download Database
         */
        $('.oc-download-db').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('This will download your entire database as a .sql file. Continue?')) {
                return;
            }
            
            var $button = $(this);
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Preparing download...');
            
            // Trigger download via direct link
            window.location.href = ocEssentials.ajax_url + '?action=oc_download_database&nonce=' + ocEssentials.nonce;
            
            // Re-enable button after delay
            setTimeout(function() {
                $button.prop('disabled', false).text(originalText);
                showNotice('success', 'Database download started');
            }, 3000);
        });
        
        /**
         * Download Entire Site
         */
        $('.oc-download-site').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('This will create a complete backup of your site including all files and the database. This may take several minutes depending on your site size. Continue?')) {
                return;
            }
            
            var $button = $(this);
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Creating backup... This may take a while...');
            
            showNotice('info', 'Creating site backup. Please do not close this window...');
            
            // Trigger download
            window.location.href = ocEssentials.ajax_url + '?action=oc_download_site&nonce=' + ocEssentials.nonce;
            
            // Re-enable button after delay
            setTimeout(function() {
                $button.prop('disabled', false).text(originalText);
            }, 10000);
        });
        
        /**
         * Download Files Only
         */
        $('.oc-download-files').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('This will download all site files except media library content. Continue?')) {
                return;
            }
            
            var $button = $(this);
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Creating backup... Please wait...');
            
            showNotice('info', 'Creating files backup. Please wait...');
            
            window.location.href = ocEssentials.ajax_url + '?action=oc_download_files_only&nonce=' + ocEssentials.nonce;
            
            setTimeout(function() {
                $button.prop('disabled', false).text(originalText);
            }, 8000);
        });
        
        /**
         * Regenerate Thumbnails
         */
        $('.oc-regenerate-thumbs').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('This will delete and regenerate ALL image thumbnails. This may take several minutes. Continue?')) {
                return;
            }
            
            var $button = $(this);
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Regenerating... Please wait...');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_regenerate_thumbnails',
                nonce: ocEssentials.nonce
            })
            .done(function(response) {
                $button.prop('disabled', false).text(originalText);
                if (response.success) {
                    showNotice('success', response.data.message);
                } else {
                    showNotice('error', 'Error: ' + (response.data || 'Unknown error'));
                }
            })
            .fail(function() {
                $button.prop('disabled', false).text(originalText);
                showNotice('error', 'Network error occurred');
            });
        });
        
        /**
         * Delete Unattached Media
         */
        $('.oc-delete-unattached').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('⚠️ WARNING: This will PERMANENTLY DELETE all unattached media files and their thumbnails. This action cannot be undone. Are you absolutely sure?')) {
                return;
            }
            
            var $button = $(this);
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Deleting...');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_delete_unattached',
                nonce: ocEssentials.nonce
            })
            .done(function(response) {
                $button.prop('disabled', false).text(originalText);
                if (response.success) {
                    showNotice('success', response.data.message);
                } else {
                    showNotice('error', 'Error: ' + (response.data || 'Unknown error'));
                }
            })
            .fail(function() {
                $button.prop('disabled', false).text(originalText);
                showNotice('error', 'Network error occurred');
            });
        });
        
        /**
         * Clear Site Cache
         */
        $('.oc-clear-cache').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.text();
            var postId = $button.data('post-id') || 0;
            
            $button.prop('disabled', true).text('Clearing...');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_clear_cache',
                nonce: ocEssentials.nonce,
                post_id: postId
            })
            .done(function(response) {
                $button.prop('disabled', false).text(originalText);
                if (response.success) {
                    showNotice('success', response.data.message);
                } else {
                    showNotice('error', 'Error: ' + (response.data || 'Unknown error'));
                }
            })
            .fail(function() {
                $button.prop('disabled', false).text(originalText);
                showNotice('error', 'Network error occurred');
            });
        });
        
        /**
         * Scan Orphaned Content
         */
        $('.oc-scan-orphaned').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $results = $('#oc-orphaned-results');
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Scanning...');
            $results.html('<p class="oc-loading">🔍 Scanning for orphaned content... This may take a moment...</p>');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_scan_orphaned',
                nonce: ocEssentials.nonce
            })
            .done(function(response) {
                $button.prop('disabled', false).text(originalText);
                
                if (response.success) {
                    var orphaned = response.data.orphaned;
                    
                    if (orphaned.length === 0) {
                        $results.html('<p class="oc-success">✓ Great! No orphaned content found. All your posts and pages are linked from somewhere.</p>');
                    } else {
                        var html = '<h4>Found ' + orphaned.length + ' orphaned item' + (orphaned.length > 1 ? 's' : '') + ':</h4>';
                        html += '<div class="oc-orphaned-list">';
                        
                        orphaned.forEach(function(item) {
                            html += '<div class="oc-orphaned-item">';
                            html += '<h5><a href="' + escapeHtml(item.edit_url) + '" target="_blank">' + escapeHtml(item.title) + '</a></h5>';
                            html += '<p><small>' + escapeHtml(item.type) + ' - <a href="' + escapeHtml(item.url) + '" target="_blank">View Page</a></small></p>';
                            
                            if (item.suggestions && item.suggestions.length > 0) {
                                html += '<p><strong>💡 Suggested posts to link from:</strong></p><ul>';
                                item.suggestions.forEach(function(sug) {
                                    html += '<li><a href="' + escapeHtml(sug.edit_url) + '" target="_blank">' + escapeHtml(sug.title) + '</a></li>';
                                });
                                html += '</ul>';
                            }
                            
                            html += '</div>';
                        });
                        
                        html += '</div>';
                        $results.html(html);
                    }
                } else {
                    $results.html('<p class="oc-error">❌ Error: ' + (response.data || 'Unknown error occurred') + '</p>');
                }
            })
            .fail(function() {
                $button.prop('disabled', false).text(originalText);
                $results.html('<p class="oc-error">❌ Network error occurred</p>');
            });
        });
        
        /**
         * Scan Missing Meta Data
         */
        $('.oc-scan-meta').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $results = $('#oc-meta-results');
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Scanning...');
            $results.html('<p class="oc-loading">🔍 Scanning for missing meta data...</p>');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_scan_meta',
                nonce: ocEssentials.nonce
            })
            .done(function(response) {
                $button.prop('disabled', false).text(originalText);
                
                if (response.success) {
                    var missing = response.data.missing_meta;
                    var seoPlugin = response.data.seo_plugin;
                    
                    if (seoPlugin === 'none') {
                        $results.html('<p class="oc-warning">⚠️ No SEO plugin detected. Please install Yoast SEO, Rank Math, or All in One SEO to use this feature.</p>');
                    } else if (missing.length === 0) {
                        $results.html('<p class="oc-success">✓ Excellent! All posts and pages have complete meta data.</p>');
                    } else {
                        var html = '<h4>Found ' + missing.length + ' item' + (missing.length > 1 ? 's' : '') + ' with missing meta:</h4>';
                        html += '<div class="oc-meta-list">';
                        
                        missing.forEach(function(item) {
                            html += '<div class="oc-meta-item">';
                            html += '<h5><a href="' + escapeHtml(item.edit_url) + '" target="_blank">' + escapeHtml(item.title) + '</a></h5>';
                            html += '<p><small>' + escapeHtml(item.type) + '</small></p>';
                            html += '<p><strong>⚠️ Missing:</strong> ' + escapeHtml(item.missing.join(', ')) + '</p>';
                            html += '</div>';
                        });
                        
                        html += '</div>';
                        $results.html(html);
                    }
                } else {
                    $results.html('<p class="oc-error">❌ Error: ' + (response.data || 'Unknown error occurred') + '</p>');
                }
            })
            .fail(function() {
                $button.prop('disabled', false).text(originalText);
                $results.html('<p class="oc-error">❌ Network error occurred</p>');
            });
        });
        
        /**
         * Scan Missing Alt Text
         */
        $('.oc-scan-alt').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $results = $('#oc-alt-results');
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('Scanning...');
            $results.html('<p class="oc-loading">🔍 Scanning for images without alt text...</p>');
            
            $.post(ocEssentials.ajax_url, {
                action: 'oc_scan_alt_text',
                nonce: ocEssentials.nonce
            })
            .done(function(response) {
                $button.prop('disabled', false).text(originalText);
                
                if (response.success) {
                    var missing = response.data.missing;
                    var hasAiAltTag = response.data.has_ai_alt_tag;
                    var aiUrl = response.data.ai_alt_tag_url;
                    
                    if (missing.length === 0) {
                        $results.html('<p class="oc-success">✓ Perfect! All images have alt text.</p>');
                    } else {
                        var html = '<h4>Found ' + missing.length + ' image' + (missing.length > 1 ? 's' : '') + ' without alt text</h4>';
                        
                        if (hasAiAltTag) {
                            html += '<p><a href="' + escapeHtml(aiUrl) + '" class="button button-primary" target="_blank">🤖 Fix Automatically with AI Alt Tag Manager</a></p>';
                            html += '<p class="oc-note">The AI Alt Tag Manager plugin is installed and can automatically add alt text to all images.</p>';
                        } else {
                            html += '<p class="oc-note">Tip: Install the "AI Alt Tag Manager" plugin to automatically generate alt text for all images.</p>';
                        }
                        
                        html += '<div class="oc-alt-list">';
                        
                        var displayCount = Math.min(missing.length, 10);
                        for (var i = 0; i < displayCount; i++) {
                            var item = missing[i];
                            html += '<div class="oc-alt-item">';
                            html += '<img src="' + escapeHtml(item.thumb) + '" alt="" style="max-width: 100px; max-height: 100px; object-fit: cover;">';
                            html += '<div>';
                            html += '<h5>' + escapeHtml(item.title) + '</h5>';
                            html += '<p><a href="' + escapeHtml(item.edit_url) + '" target="_blank">Edit Image</a> | <a href="' + escapeHtml(item.url) + '" target="_blank">View Full Size</a></p>';
                            html += '</div>';
                            html += '</div>';
                        }
                        
                        html += '</div>';
                        
                        if (missing.length > 10) {
                            html += '<p class="oc-note">...and ' + (missing.length - 10) + ' more image' + (missing.length - 10 > 1 ? 's' : '') + '</p>';
                        }
                        
                        $results.html(html);
                    }
                } else {
                    $results.html('<p class="oc-error">❌ Error: ' + (response.data || 'Unknown error occurred') + '</p>');
                }
            })
            .fail(function() {
                $button.prop('disabled', false).text(originalText);
                $results.html('<p class="oc-error">❌ Network error occurred</p>');
            });
        });
        
        /**
         * PageSpeed Test
         */
        $('.oc-pagespeed-test').on('click', function(e) {
            e.preventDefault();
            
            var url = 'https://pagespeed.web.dev/analysis?url=' + encodeURIComponent(ocEssentials.site_url);
            window.open(url, '_blank');
            
            showNotice('info', 'Opening PageSpeed Insights in a new tab...');
        });
        
        /**
         * Helper: Show Admin Notice
         */
        function showNotice(type, message) {
            var noticeClass = 'notice-' + type;
            var notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
            
            $('.oc-essentials-wrap h1').after(notice);
            
            // Auto-dismiss after 5 seconds
            setTimeout(function() {
                notice.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
        }
        
        /**
         * Helper: Escape HTML
         */
        function escapeHtml(text) {
            var map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
        }
        
    });
    
})(jQuery);
