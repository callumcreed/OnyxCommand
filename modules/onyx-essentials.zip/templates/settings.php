<?php
/**
 * Onyx Essentials Settings Template
 * Place in: modules/onyx-essentials/templates/settings.php
 */

if (!defined('ABSPATH')) exit;
?>

<div class="wrap oc-essentials-wrap">
    <h1>⚡ Onyx Essentials</h1>
    <p class="description">Comprehensive security, optimization, and maintenance tools for your WordPress site.</p>
    
    <form method="post" action="">
        <?php wp_nonce_field('oc_essentials_settings'); ?>
        
        <div class="oc-essentials-grid">
            
            <!-- Security Features -->
            <div class="oc-essentials-section">
                <h2>🔒 Security Features</h2>
                
                <!-- Feature 1: SSL Status -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="ssl_check" value="1" <?php checked(!empty($options['ssl_check'])); ?>>
                            <strong>SSL Certificate Monitor</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Monitor SSL certificate status and expiration</p>
                        <?php if (!empty($options['ssl_check'])): ?>
                            <div class="oc-ssl-status">
                                <?php if ($ssl_info['status'] === 'Active'): ?>
                                    <span class="oc-status-badge oc-status-success">✓ Active</span>
                                    <p><strong>Expires:</strong> <?php echo esc_html($ssl_info['expiry_date']); ?></p>
                                    <p><strong>Days Remaining:</strong> <?php echo esc_html($ssl_info['days_remaining']); ?> days</p>
                                    <?php if ($ssl_info['days_remaining'] < 30): ?>
                                        <p class="oc-warning">⚠️ Your SSL certificate will expire soon!</p>
                                    <?php endif; ?>
                                <?php elseif ($ssl_info['status'] === 'Expired'): ?>
                                    <span class="oc-status-badge oc-status-error">✗ Expired</span>
                                    <p><strong>Expired on:</strong> <?php echo esc_html($ssl_info['expiry_date']); ?></p>
                                    <div class="oc-ssl-help">
                                        <p><strong>Get a new SSL certificate from:</strong></p>
                                        <ul>
                                            <li><a href="https://letsencrypt.org/" target="_blank">Let's Encrypt</a> - Free SSL certificates</li>
                                            <li><a href="https://www.cloudflare.com/ssl/" target="_blank">Cloudflare</a> - Free SSL with CDN</li>
                                        </ul>
                                        <p><strong>Manual Installation Instructions:</strong></p>
                                        <ol>
                                            <li>Generate or obtain SSL certificate and private key files</li>
                                            <li>Access your hosting control panel (cPanel, Plesk, etc.)</li>
                                            <li>Navigate to SSL/TLS section</li>
                                            <li>Upload certificate (.crt) and private key (.key) files</li>
                                            <li>Save and apply changes</li>
                                        </ol>
                                    </div>
                                <?php else: ?>
                                    <span class="oc-status-badge oc-status-warning">! Not Active</span>
                                    <p>SSL is not currently active on this site</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Feature 2: Force 2FA -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="force_2fa" value="1" <?php checked(!empty($options['force_2fa'])); ?>>
                            <strong>Force Two-Factor Authentication</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Require administrators and contributors to set up 2FA before accessing the dashboard</p>
                        <p class="oc-note">Note: Requires a 2FA plugin like "Two Factor Authentication" or "WP 2FA"</p>
                    </div>
                </div>
                
                <!-- Feature 3: Disable File Editing -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="disable_file_editing" value="1" <?php checked(!empty($options['disable_file_editing'])); ?>>
                            <strong>Disable File Editing</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Disable theme and plugin file editing for non-administrators</p>
                    </div>
                </div>
                
                <!-- Feature 4: Disable XML-RPC -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="disable_xmlrpc" value="1" <?php checked(!empty($options['disable_xmlrpc'])); ?>>
                            <strong>Disable XML-RPC</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Disable XML-RPC to prevent brute force attacks</p>
                    </div>
                </div>
                
                <!-- Feature 5: Disable wp-config Editing -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="disable_wpconfig_edit" value="1" <?php checked(!empty($options['disable_wpconfig_edit'])); ?>>
                            <strong>Protect wp-config.php</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Prevent wp-config.php editing except by administrators</p>
                    </div>
                </div>
                
                <!-- Feature 6: Hide WordPress Version -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="hide_wp_version" value="1" <?php checked(!empty($options['hide_wp_version'])); ?>>
                            <strong>Hide WordPress Version</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Remove WordPress version from public HTML source</p>
                    </div>
                </div>
                
                <!-- Feature 12: Strong Passwords -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="enforce_strong_passwords" value="1" <?php checked(!empty($options['enforce_strong_passwords'])); ?>>
                            <strong>Enforce Strong Passwords</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Require passwords with 8+ characters, uppercase, lowercase, number, and special character</p>
                    </div>
                </div>
                
                <!-- Feature 13: Limit Login Attempts -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="limit_login_attempts" value="1" <?php checked(!empty($options['limit_login_attempts'])); ?>>
                            <strong>Limit Login Attempts</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Lock accounts after failed login attempts</p>
                        <label>
                            Maximum attempts:
                            <select name="login_attempt_limit">
                                <option value="3" <?php selected(!empty($options['login_attempt_limit']) ? $options['login_attempt_limit'] : 5, 3); ?>>3</option>
                                <option value="5" <?php selected(!empty($options['login_attempt_limit']) ? $options['login_attempt_limit'] : 5, 5); ?>>5</option>
                                <option value="10" <?php selected(!empty($options['login_attempt_limit']) ? $options['login_attempt_limit'] : 5, 10); ?>>10</option>
                            </select>
                        </label>
                    </div>
                </div>
                
                <!-- Feature 14: Block Invalid Usernames -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="block_invalid_usernames" value="1" <?php checked(!empty($options['block_invalid_usernames'])); ?>>
                            <strong>Block Invalid Username Attempts</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Automatically block IPs attempting to login with non-existent usernames</p>
                    </div>
                </div>
            </div>
            
            <!-- User Management -->
            <div class="oc-essentials-section">
                <h2>👥 User Management</h2>
                
                <!-- Feature 7: Keep Admin Logged In -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="keep_admin_logged_in" value="1" <?php checked(!empty($options['keep_admin_logged_in'])); ?>>
                            <strong>Keep Administrators Logged In</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Extend admin session to 10 years (until manual logout)</p>
                    </div>
                </div>
                
                <!-- Feature 8 & 11: Change Admin Username -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="change_admin_username" value="1" <?php checked(!empty($options['change_admin_username'])); ?>>
                            <strong>Change Default Admin Username</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Change the default 'admin' username for security</p>
                        <label>
                            New username:
                            <input type="text" name="new_admin_username" value="guestwork" placeholder="guestwork">
                        </label>
                        <p class="oc-note">Suggested default: guestwork</p>
                    </div>
                </div>
                
                <!-- Locked Users Display -->
                <?php if (!empty($locked_users)): ?>
                <div class="oc-feature-card oc-locked-section">
                    <h3>🔒 Locked User Accounts</h3>
                    <table class="oc-table">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>IP Address</th>
                                <th>Country</th>
                                <th>Attempts</th>
                                <th>Locked At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($locked_users as $user_id => $data): ?>
                            <tr>
                                <td><?php echo esc_html($data['username']); ?></td>
                                <td><?php echo esc_html($data['email']); ?></td>
                                <td><?php echo esc_html($data['ip']); ?></td>
                                <td><?php echo esc_html($data['country']); ?></td>
                                <td><?php echo esc_html($data['attempts']); ?></td>
                                <td><?php echo esc_html($data['locked_at']); ?></td>
                                <td>
                                    <button type="button" class="button oc-unlock-user" data-user-id="<?php echo esc_attr($user_id); ?>">Unlock</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                
                <!-- Locked IPs Display -->
                <?php if (!empty($locked_ips)): ?>
                <div class="oc-feature-card oc-locked-section">
                    <h3>🚫 Locked IP Addresses</h3>
                    <table class="oc-table">
                        <thead>
                            <tr>
                                <th>IP Address</th>
                                <th>Attempted Username</th>
                                <th>Country</th>
                                <th>Locked At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($locked_ips as $ip => $data): ?>
                            <tr>
                                <td><?php echo esc_html($ip); ?></td>
                                <td><?php echo esc_html($data['username']); ?></td>
                                <td><?php echo esc_html($data['country']); ?></td>
                                <td><?php echo esc_html($data['locked_at']); ?></td>
                                <td>
                                    <button type="button" class="button oc-unlock-ip" data-ip="<?php echo esc_attr($ip); ?>">Unlock</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Content Management -->
            <div class="oc-essentials-section">
                <h2>📝 Content Management</h2>
                
                <!-- Feature 9: Disable Comments -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="disable_comments" value="1" <?php checked(!empty($options['disable_comments'])); ?>>
                            <strong>Disable Comments Sitewide</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Disable comments globally with per-post override option</p>
                    </div>
                </div>
                
                <!-- Feature 21: Scan Orphaned Content -->
                <div class="oc-feature-card">
                    <h3>🔍 Scan for Orphaned Content</h3>
                    <p>Find posts and pages with no incoming links</p>
                    <button type="button" class="button button-secondary oc-scan-orphaned">Scan Now</button>
                    <div id="oc-orphaned-results" class="oc-results"></div>
                </div>
                
                <!-- Feature 22: Scan Missing Meta -->
                <div class="oc-feature-card">
                    <h3>🏷️ Scan for Missing Meta Data</h3>
                    <p>Find posts missing SEO meta information</p>
                    <button type="button" class="button button-secondary oc-scan-meta">Scan Now</button>
                    <div id="oc-meta-results" class="oc-results"></div>
                </div>
                
                <!-- Feature 23: Scan Missing Alt Text -->
                <div class="oc-feature-card">
                    <h3>🖼️ Scan for Missing Alt Text</h3>
                    <p>Find images without alt text</p>
                    <button type="button" class="button button-secondary oc-scan-alt">Scan Now</button>
                    <div id="oc-alt-results" class="oc-results"></div>
                </div>
            </div>
            
            <!-- Media Management -->
            <div class="oc-essentials-section">
                <h2>🖼️ Media Management</h2>
                
                <!-- Feature 18: Regenerate Thumbnails -->
                <div class="oc-feature-card">
                    <h3>🔄 Regenerate Thumbnails</h3>
                    <p>Delete and regenerate all image thumbnails</p>
                    <button type="button" class="button button-secondary oc-regenerate-thumbs">Regenerate All Thumbnails</button>
                </div>
                
                <!-- Feature 19: Delete Unattached Media -->
                <div class="oc-feature-card">
                    <h3>🗑️ Delete Unattached Media</h3>
                    <p>Remove media files not attached to any post</p>
                    <button type="button" class="button button-secondary oc-delete-unattached">Delete Unattached Files</button>
                </div>
            </div>
            
            <!-- Backup & Maintenance -->
            <div class="oc-essentials-section">
                <h2>💾 Backup & Maintenance</h2>
                
                <!-- Feature 10 & 17: Download Database -->
                <div class="oc-feature-card">
                    <h3>📦 Download Database Backup</h3>
                    <p>Export complete SQL database backup</p>
                    <button type="button" class="button button-primary oc-download-db">Download Database Only</button>
                </div>
                
                <!-- Feature 15: Download Entire Site -->
                <div class="oc-feature-card">
                    <h3>📦 Download Entire Site</h3>
                    <p>Download complete site including files and database</p>
                    <button type="button" class="button button-primary oc-download-site">Download Entire Site</button>
                </div>
                
                <!-- Feature 16: Download Files Only -->
                <div class="oc-feature-card">
                    <h3>📦 Download Files Only</h3>
                    <p>Download site files without media library content</p>
                    <button type="button" class="button button-primary oc-download-files">Download Files Only</button>
                </div>
                
                <!-- Feature 20: Clear Cache -->
                <div class="oc-feature-card">
                    <h3>🧹 Clear Cache</h3>
                    <p>Clear entire site cache</p>
                    <button type="button" class="button button-secondary oc-clear-cache">Clear Entire Site Cache</button>
                </div>
            </div>
            
            <!-- Performance & Optimization -->
            <div class="oc-essentials-section">
                <h2>⚡ Performance & Optimization</h2>
                
                <!-- Feature 24: Disable Emojis -->
                <div class="oc-feature-card">
                    <div class="oc-feature-header">
                        <label>
                            <input type="checkbox" name="disable_emojis" value="1" <?php checked(!empty($options['disable_emojis'])); ?>>
                            <strong>Disable WordPress Emojis</strong>
                        </label>
                    </div>
                    <div class="oc-feature-body">
                        <p>Remove emoji scripts and styles to improve performance</p>
                    </div>
                </div>
                
                <!-- Feature 25: PageSpeed Test -->
                <div class="oc-feature-card">
                    <h3>🚀 PageSpeed Insights</h3>
                    <p>Test your site's performance with Google PageSpeed Insights</p>
                    <button type="button" class="button button-secondary oc-pagespeed-test">Perform PageSpeed Test</button>
                </div>
            </div>
            
        </div>
        
        <div class="oc-save-section">
            <button type="submit" name="oc_essentials_save" class="button button-primary button-large">Save All Settings</button>
        </div>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    
    // Unlock user
    $('.oc-unlock-user').on('click', function() {
        if (!confirm('Are you sure you want to unlock this user account?')) return;
        
        var userId = $(this).data('user-id');
        var button = $(this);
        
        button.prop('disabled', true).text('Unlocking...');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_unlock_user',
            nonce: ocEssentials.nonce,
            user_id: userId
        }, function(response) {
            if (response.success) {
                button.closest('tr').fadeOut();
                alert(response.data.message);
            } else {
                alert('Error: ' + response.data);
                button.prop('disabled', false).text('Unlock');
            }
        });
    });
    
    // Unlock IP
    $('.oc-unlock-ip').on('click', function() {
        if (!confirm('Are you sure you want to unlock this IP address?')) return;
        
        var ip = $(this).data('ip');
        var button = $(this);
        
        button.prop('disabled', true).text('Unlocking...');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_unlock_ip',
            nonce: ocEssentials.nonce,
            ip: ip
        }, function(response) {
            if (response.success) {
                button.closest('tr').fadeOut();
                alert(response.data.message);
            } else {
                alert('Error: ' + response.data);
                button.prop('disabled', false).text('Unlock');
            }
        });
    });
    
    // Download database
    $('.oc-download-db').on('click', function() {
        if (!confirm('This will download your database. Continue?')) return;
        
        var button = $(this);
        button.prop('disabled', true).text('Preparing download...');
        
        window.location.href = ocEssentials.ajax_url + '?action=oc_download_database&nonce=' + ocEssentials.nonce;
        
        setTimeout(function() {
            button.prop('disabled', false).text('Download Database Only');
        }, 3000);
    });
    
    // Download entire site
    $('.oc-download-site').on('click', function() {
        if (!confirm('This will create a complete backup of your site. This may take several minutes. Continue?')) return;
        
        var button = $(this);
        button.prop('disabled', true).text('Creating backup... Please wait...');
        
        window.location.href = ocEssentials.ajax_url + '?action=oc_download_site&nonce=' + ocEssentials.nonce;
        
        setTimeout(function() {
            button.prop('disabled', false).text('Download Entire Site');
        }, 5000);
    });
    
    // Download files only
    $('.oc-download-files').on('click', function() {
        if (!confirm('This will download all files except media library content. Continue?')) return;
        
        var button = $(this);
        button.prop('disabled', true).text('Creating backup... Please wait...');
        
        window.location.href = ocEssentials.ajax_url + '?action=oc_download_files_only&nonce=' + ocEssentials.nonce;
        
        setTimeout(function() {
            button.prop('disabled', false).text('Download Files Only');
        }, 5000);
    });
    
    // Regenerate thumbnails
    $('.oc-regenerate-thumbs').on('click', function() {
        if (!confirm('This will delete and regenerate ALL thumbnails. This may take several minutes. Continue?')) return;
        
        var button = $(this);
        button.prop('disabled', true).text('Regenerating... Please wait...');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_regenerate_thumbnails',
            nonce: ocEssentials.nonce
        }, function(response) {
            button.prop('disabled', false).text('Regenerate All Thumbnails');
            if (response.success) {
                alert(response.data.message);
            } else {
                alert('Error: ' + response.data);
            }
        });
    });
    
    // Delete unattached media
    $('.oc-delete-unattached').on('click', function() {
        if (!confirm('This will PERMANENTLY DELETE all unattached media files and their thumbnails. This cannot be undone. Continue?')) return;
        
        var button = $(this);
        button.prop('disabled', true).text('Deleting...');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_delete_unattached',
            nonce: ocEssentials.nonce
        }, function(response) {
            button.prop('disabled', false).text('Delete Unattached Files');
            if (response.success) {
                alert(response.data.message);
            } else {
                alert('Error: ' + response.data);
            }
        });
    });
    
    // Clear cache
    $('.oc-clear-cache').on('click', function() {
        var button = $(this);
        button.prop('disabled', true).text('Clearing...');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_clear_cache',
            nonce: ocEssentials.nonce
        }, function(response) {
            button.prop('disabled', false).text('Clear Entire Site Cache');
            if (response.success) {
                alert(response.data.message);
            } else {
                alert('Error: ' + response.data);
            }
        });
    });
    
    // Scan orphaned content
    $('.oc-scan-orphaned').on('click', function() {
        var button = $(this);
        var results = $('#oc-orphaned-results');
        
        button.prop('disabled', true).text('Scanning...');
        results.html('<p>Scanning for orphaned content...</p>');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_scan_orphaned',
            nonce: ocEssentials.nonce
        }, function(response) {
            button.prop('disabled', false).text('Scan Now');
            
            if (response.success) {
                var orphaned = response.data.orphaned;
                if (orphaned.length === 0) {
                    results.html('<p class="oc-success">✓ No orphaned content found!</p>');
                } else {
                    var html = '<h4>Found ' + orphaned.length + ' orphaned items:</h4><div class="oc-orphaned-list">';
                    orphaned.forEach(function(item) {
                        html += '<div class="oc-orphaned-item">';
                        html += '<h5><a href="' + item.edit_url + '" target="_blank">' + item.title + '</a></h5>';
                        html += '<p><small>' + item.type + ' - <a href="' + item.url + '" target="_blank">View</a></small></p>';
                        if (item.suggestions.length > 0) {
                            html += '<p><strong>Suggested posts to link from:</strong></p><ul>';
                            item.suggestions.forEach(function(sug) {
                                html += '<li><a href="' + sug.edit_url + '" target="_blank">' + sug.title + '</a></li>';
                            });
                            html += '</ul>';
                        }
                        html += '</div>';
                    });
                    html += '</div>';
                    results.html(html);
                }
            } else {
                results.html('<p class="oc-error">Error: ' + response.data + '</p>');
            }
        });
    });
    
    // Scan missing meta
    $('.oc-scan-meta').on('click', function() {
        var button = $(this);
        var results = $('#oc-meta-results');
        
        button.prop('disabled', true).text('Scanning...');
        results.html('<p>Scanning for missing meta data...</p>');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_scan_meta',
            nonce: ocEssentials.nonce
        }, function(response) {
            button.prop('disabled', false).text('Scan Now');
            
            if (response.success) {
                var missing = response.data.missing_meta;
                var seo_plugin = response.data.seo_plugin;
                
                if (seo_plugin === 'none') {
                    results.html('<p class="oc-warning">⚠️ No SEO plugin detected. Install Yoast SEO, Rank Math, or All in One SEO.</p>');
                } else if (missing.length === 0) {
                    results.html('<p class="oc-success">✓ All posts have complete meta data!</p>');
                } else {
                    var html = '<h4>Found ' + missing.length + ' items with missing meta:</h4><div class="oc-meta-list">';
                    missing.forEach(function(item) {
                        html += '<div class="oc-meta-item">';
                        html += '<h5><a href="' + item.edit_url + '" target="_blank">' + item.title + '</a></h5>';
                        html += '<p><small>' + item.type + '</small></p>';
                        html += '<p><strong>Missing:</strong> ' + item.missing.join(', ') + '</p>';
                        html += '</div>';
                    });
                    html += '</div>';
                    results.html(html);
                }
            } else {
                results.html('<p class="oc-error">Error: ' + response.data + '</p>');
            }
        });
    });
    
    // Scan missing alt text
    $('.oc-scan-alt').on('click', function() {
        var button = $(this);
        var results = $('#oc-alt-results');
        
        button.prop('disabled', true).text('Scanning...');
        results.html('<p>Scanning for images without alt text...</p>');
        
        $.post(ocEssentials.ajax_url, {
            action: 'oc_scan_alt_text',
            nonce: ocEssentials.nonce
        }, function(response) {
            button.prop('disabled', false).text('Scan Now');
            
            if (response.success) {
                var missing = response.data.missing;
                var hasAiAltTag = response.data.has_ai_alt_tag;
                var aiUrl = response.data.ai_alt_tag_url;
                
                if (missing.length === 0) {
                    results.html('<p class="oc-success">✓ All images have alt text!</p>');
                } else {
                    var html = '<h4>Found ' + missing.length + ' images without alt text</h4>';
                    
                    if (hasAiAltTag) {
                        html += '<p><a href="' + aiUrl + '" class="button button-primary" target="_blank">Fix with AI Alt Tag Manager</a></p>';
                    } else {
                        html += '<div class="oc-alt-list">';
                        missing.slice(0, 10).forEach(function(item) {
                            html += '<div class="oc-alt-item">';
                            html += '<img src="' + item.thumb + '" alt="" style="max-width: 100px;">';
                            html += '<div>';
                            html += '<h5>' + item.title + '</h5>';
                            html += '<p><a href="' + item.edit_url + '" target="_blank">Edit Image</a></p>';
                            html += '</div>';
                            html += '</div>';
                        });
                        html += '</div>';
                        if (missing.length > 10) {
                            html += '<p>...and ' + (missing.length - 10) + ' more</p>';
                        }
                    }
                    
                    results.html(html);
                }
            } else {
                results.html('<p class="oc-error">Error: ' + response.data + '</p>');
            }
        });
    });
    
    // PageSpeed test
    $('.oc-pagespeed-test').on('click', function() {
        var url = 'https://pagespeed.web.dev/analysis?url=' + encodeURIComponent(ocEssentials.site_url);
        window.open(url, '_blank');
    });
    
});
</script>
